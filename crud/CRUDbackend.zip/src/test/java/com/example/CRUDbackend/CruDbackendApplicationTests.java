package com.example.CRUDbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CruDbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
