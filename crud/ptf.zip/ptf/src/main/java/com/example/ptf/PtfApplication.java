package com.example.ptf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PtfApplication {

	public static void main(String[] args) {
		SpringApplication.run(PtfApplication.class, args);
	}

}
